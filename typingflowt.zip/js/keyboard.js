/* ==========================================================================
   Typing Web Application - Virtual Keyboard & Finger Posture Renderer
   ========================================================================== */

class VirtualKeyboardManager {
  constructor(containerId = 'virtual-keyboard') {
    this.container = document.getElementById(containerId);
    this.fingerGuidePill = document.getElementById('finger-guide-text');
    this.keyMap = new Map();
    
    // Key definitions with finger bindings:
    // lp: Left Pinky, lr: Left Ring, lm: Left Middle, li: Left Index, th: Thumb
    // ri: Right Index, rm: Right Middle, rr: Right Ring, rp: Right Pinky
    this.layout = [
      [
        { code: 'Backquote', key: '`', shiftKey: '~', finger: 'lp' },
        { code: 'Digit1', key: '1', shiftKey: '!', finger: 'lp' },
        { code: 'Digit2', key: '2', shiftKey: '@', finger: 'lr' },
        { code: 'Digit3', key: '3', shiftKey: '#', finger: 'lm' },
        { code: 'Digit4', key: '4', shiftKey: '$', finger: 'li' },
        { code: 'Digit5', key: '5', shiftKey: '%', finger: 'li' },
        { code: 'Digit6', key: '6', shiftKey: '^', finger: 'ri' },
        { code: 'Digit7', key: '7', shiftKey: '&', finger: 'ri' },
        { code: 'Digit8', key: '8', shiftKey: '*', finger: 'rm' },
        { code: 'Digit9', key: '9', shiftKey: '(', finger: 'rr' },
        { code: 'Digit0', key: '0', shiftKey: ')', finger: 'rp' },
        { code: 'Minus', key: '-', shiftKey: '_', finger: 'rp' },
        { code: 'Equal', key: '=', shiftKey: '+', finger: 'rp' },
        { code: 'Backspace', key: 'Backspace', label: '⌫ Back', finger: 'rp', class: 'key-backspace' }
      ],
      [
        { code: 'Tab', key: 'Tab', label: 'Tab ↹', finger: 'lp', class: 'key-tab' },
        { code: 'KeyQ', key: 'q', shiftKey: 'Q', finger: 'lp' },
        { code: 'KeyW', key: 'w', shiftKey: 'W', finger: 'lr' },
        { code: 'KeyE', key: 'e', shiftKey: 'E', finger: 'lm' },
        { code: 'KeyR', key: 'r', shiftKey: 'R', finger: 'li' },
        { code: 'KeyT', key: 't', shiftKey: 'T', finger: 'li' },
        { code: 'KeyY', key: 'y', shiftKey: 'Y', finger: 'ri' },
        { code: 'KeyU', key: 'u', shiftKey: 'U', finger: 'ri' },
        { code: 'KeyI', key: 'i', shiftKey: 'I', finger: 'rm' },
        { code: 'KeyO', key: 'o', shiftKey: 'O', finger: 'rr' },
        { code: 'KeyP', key: 'p', shiftKey: 'P', finger: 'rp' },
        { code: 'BracketLeft', key: '[', shiftKey: '{', finger: 'rp' },
        { code: 'BracketRight', key: ']', shiftKey: '}', finger: 'rp' },
        { code: 'Backslash', key: '\\', shiftKey: '|', finger: 'rp' }
      ],
      [
        { code: 'CapsLock', key: 'CapsLock', label: 'Caps ⇪', finger: 'lp', class: 'key-caps' },
        { code: 'KeyA', key: 'a', shiftKey: 'A', finger: 'lp' },
        { code: 'KeyS', key: 's', shiftKey: 'S', finger: 'lr' },
        { code: 'KeyD', key: 'd', shiftKey: 'D', finger: 'lm' },
        { code: 'KeyF', key: 'f', shiftKey: 'F', finger: 'li' },
        { code: 'KeyG', key: 'g', shiftKey: 'G', finger: 'li' },
        { code: 'KeyH', key: 'h', shiftKey: 'H', finger: 'ri' },
        { code: 'KeyJ', key: 'j', shiftKey: 'J', finger: 'ri' },
        { code: 'KeyK', key: 'k', shiftKey: 'K', finger: 'rm' },
        { code: 'KeyL', key: 'l', shiftKey: 'L', finger: 'rr' },
        { code: 'Semicolon', key: ';', shiftKey: ':', finger: 'rp' },
        { code: 'Quote', key: "'", shiftKey: '"', finger: 'rp' },
        { code: 'Enter', key: 'Enter', label: 'Enter ↵', finger: 'rp', class: 'key-enter' }
      ],
      [
        { code: 'ShiftLeft', key: 'Shift', label: '⇧ Shift', finger: 'lp', class: 'key-shift' },
        { code: 'KeyZ', key: 'z', shiftKey: 'Z', finger: 'lp' },
        { code: 'KeyX', key: 'x', shiftKey: 'X', finger: 'lr' },
        { code: 'KeyC', key: 'c', shiftKey: 'C', finger: 'lm' },
        { code: 'KeyV', key: 'v', shiftKey: 'V', finger: 'li' },
        { code: 'KeyB', key: 'b', shiftKey: 'B', finger: 'li' },
        { code: 'KeyN', key: 'n', shiftKey: 'N', finger: 'ri' },
        { code: 'KeyM', key: 'm', shiftKey: 'M', finger: 'ri' },
        { code: 'Comma', key: ',', shiftKey: '<', finger: 'rm' },
        { code: 'Period', key: '.', shiftKey: '>', finger: 'rr' },
        { code: 'Slash', key: '/', shiftKey: '?', finger: 'rp' },
        { code: 'ShiftRight', key: 'Shift', label: '⇧ Shift', finger: 'rp', class: 'key-shift' }
      ],
      [
        { code: 'Space', key: ' ', label: 'Spacebar', finger: 'th', class: 'key-space' }
      ]
    ];

    this.fingerNames = {
      lp: 'Left Pinky',
      lr: 'Left Ring',
      lm: 'Left Middle',
      li: 'Left Index',
      th: 'Thumb (Left/Right)',
      ri: 'Right Index',
      rm: 'Right Middle',
      rr: 'Right Ring',
      rp: 'Right Pinky'
    };
  }

  render() {
    if (!this.container) return;
    this.container.innerHTML = '';

    const layoutContainer = document.createElement('div');
    layoutContainer.className = 'keyboard-layout';

    this.layout.forEach(row => {
      const rowEl = document.createElement('div');
      rowEl.className = 'kb-row';

      row.forEach(k => {
        const keyEl = document.createElement('div');
        keyEl.className = `key ${k.class || ''}`;
        keyEl.setAttribute('data-code', k.code);
        keyEl.setAttribute('data-finger', k.finger);
        keyEl.textContent = k.label || k.key;

        rowEl.appendChild(keyEl);

        // Add touch/click handler for mobile virtual key taps
        const handleKeyPress = (e) => {
          e.preventDefault();
          if (window.app && typeof window.app.processInputKey === 'function') {
            window.app.processInputKey(k.key, k.code);
          }
        };

        keyEl.addEventListener('pointerdown', handleKeyPress);

        // Map characters to key element
        this.keyMap.set(k.code, keyEl);
        if (k.key) this.keyMap.set(k.key, keyEl);
        if (k.shiftKey) this.keyMap.set(k.shiftKey, keyEl);
      });

      layoutContainer.appendChild(rowEl);
    });

    this.container.appendChild(layoutContainer);
  }

  handleKeyDown(code, char) {
    let keyEl = this.keyMap.get(code) || this.keyMap.get(char);
    if (keyEl) {
      keyEl.classList.add('pressed');
    }
  }

  handleKeyUp(code, char) {
    let keyEl = this.keyMap.get(code) || this.keyMap.get(char);
    if (keyEl) {
      keyEl.classList.remove('pressed');
    }
  }

  highlightTargetKey(char) {
    // Clear existing target highlights
    this.container.querySelectorAll('.key.target').forEach(el => el.classList.remove('target'));

    if (!char) {
      if (this.fingerGuidePill) this.fingerGuidePill.textContent = 'Ready';
      return;
    }

    let targetChar = char;
    if (char === ' ') targetChar = 'Space';

    let keyEl = this.keyMap.get(targetChar);
    
    // Check uppercase / shift keys
    if (!keyEl && char.toUpperCase() === char && char.toLowerCase() !== char) {
      keyEl = this.keyMap.get(char.toLowerCase());
      // Highlight shift key as well
      const shiftEl = this.keyMap.get('ShiftLeft') || this.keyMap.get('ShiftRight');
      if (shiftEl) shiftEl.classList.add('target');
    }

    if (keyEl) {
      keyEl.classList.add('target');
      const finger = keyEl.getAttribute('data-finger');
      if (this.fingerGuidePill && finger && this.fingerNames[finger]) {
        this.fingerGuidePill.textContent = `Finger: ${this.fingerNames[finger]}`;
      }
    }
  }
}

const keyboardManager = new VirtualKeyboardManager();
