/* ==========================================================================
   Typing Web Application - Main Application Controller & Typing Engine
   ========================================================================== */

class TypingApp {
  constructor() {
    // Mode Configuration
    this.mode = 'time'; // 'time', 'words', 'custom', 'zen'
    this.timeLimit = 30; // 15, 30, 60, 120
    this.wordLimit = 25; // 10, 25, 50, 100
    this.subCategory = 'standard'; // 'standard', 'punctuation', 'numbers', 'quote', 'code'
    this.currentLessonId = null;

    // Test Engine State
    this.wordsList = [];
    this.wordElements = [];
    this.currentWordIdx = 0;
    this.currentCharIdx = 0;
    this.typedHistory = []; // Array of typed strings for each word
    
    this.timer = null;
    this.timeLeft = 30;
    this.startTime = null;
    this.testActive = false;
    this.testFinished = false;

    // Metrics Tracking
    this.totalKeystrokes = 0;
    this.correctKeystrokes = 0;
    this.errorKeystrokes = 0;
    this.wpmHistory = []; // Snapshots for timeline graph
    this.mistakeKeyMap = {}; // Tracks error counts per character

    // Settings
    this.theme = localStorage.getItem('typing_theme') || 'midnight';
    this.soundProfile = localStorage.getItem('typing_sound') || 'blue';
    this.caretStyle = localStorage.getItem('typing_caret') || 'line';

    // DOM Elements
    this.initDOMElements();
  }

  initDOMElements() {
    this.typingBox = document.getElementById('typing-box');
    this.wordsContainer = document.getElementById('words-container');
    this.caret = document.getElementById('caret');
    this.mobileInput = document.getElementById('mobile-input');
    this.liveWpm = document.getElementById('live-wpm');
    this.liveAccuracy = document.getElementById('live-acc');
    this.liveTimer = document.getElementById('live-timer');
    this.restartBtn = document.getElementById('restart-btn');

    this.navTabs = document.querySelectorAll('.nav-tab');
    this.tabPanes = document.querySelectorAll('.tab-pane');

    this.configBtns = document.querySelectorAll('.config-btn');
    this.themeSelect = document.getElementById('theme-select');
    this.soundSelect = document.getElementById('sound-select');
    this.caretSelect = document.getElementById('caret-select');

    // Modals
    this.resultsModal = document.getElementById('results-modal');
    this.modalCloseBtn = document.getElementById('modal-close-btn');
    this.modalRestartBtn = document.getElementById('modal-restart-btn');
  }

  init() {
    // 1. Render Keyboard Layout
    keyboardManager.render();

    // 2. Set Theme & Settings
    this.setTheme(this.theme);
    audioSynthesizer.setSoundProfile(this.soundProfile);

    // 3. Attach Event Listeners
    this.bindEvents();

    // 4. Render Lessons Grid
    this.renderLessonsGrid();

    // 5. Load History Stats
    this.loadHistoryStats();

    // 6. Generate First Typing Test
    this.resetTest();
  }

  bindEvents() {
    // Tab switching
    this.navTabs.forEach(tab => {
      tab.addEventListener('click', () => {
        const target = tab.getAttribute('data-tab');
        this.switchTab(target);
      });
    });

    // Config bar button clicks
    this.configBtns.forEach(btn => {
      btn.addEventListener('click', (e) => {
        const group = btn.getAttribute('data-group');
        const val = btn.getAttribute('data-val');

        // Deactivate siblings in same group
        document.querySelectorAll(`.config-btn[data-group="${group}"]`).forEach(b => b.classList.remove('active'));
        btn.classList.add('active');

        if (group === 'mode') {
          this.mode = val;
          // Toggle visibility of time vs word config groups
          document.getElementById('time-config-group').style.display = (val === 'time') ? 'flex' : 'none';
          document.getElementById('word-config-group').style.display = (val === 'words') ? 'flex' : 'none';
        } else if (group === 'time') {
          this.timeLimit = parseInt(val, 10);
        } else if (group === 'words') {
          this.wordLimit = parseInt(val, 10);
        } else if (group === 'category') {
          this.subCategory = val;
        }

        this.resetTest();
      });
    });

    // Keydown Listener on Document / Typing Box
    window.addEventListener('keydown', (e) => this.handleKeyDown(e));
    window.addEventListener('keyup', (e) => {
      keyboardManager.handleKeyUp(e.code, e.key);
    });

    // Window Resize / Orientation listener for caret recalibration
    window.addEventListener('resize', () => this.updateCaretPosition());
    window.addEventListener('orientationchange', () => {
      setTimeout(() => this.updateCaretPosition(), 100);
    });

    // Focus arena on typing box click/touch
    const focusArena = () => {
      if (this.mobileInput) {
        this.mobileInput.focus();
      }
      if (this.typingBox) {
        this.typingBox.focus();
      }
      document.querySelector('.typing-arena-wrapper')?.classList.remove('focused-out');
    };

    if (this.typingBox) {
      this.typingBox.addEventListener('click', focusArena);
      this.typingBox.addEventListener('touchstart', focusArena, { passive: true });
    }

    const overlayHint = document.querySelector('.typing-overlay-hint');
    if (overlayHint) {
      overlayHint.addEventListener('click', focusArena);
    }

    // Handle Mobile Soft Keyboard Inputs
    if (this.mobileInput) {
      this.mobileInput.addEventListener('keydown', (e) => {
        if (e.key === 'Backspace') {
          this.processInputKey('Backspace', 'Backspace');
          e.preventDefault();
        }
      });
      this.mobileInput.addEventListener('input', (e) => {
        if (e.inputType === 'deleteContentBackward') {
          this.processInputKey('Backspace', 'Backspace');
          this.mobileInput.value = '';
          return;
        }
        const val = this.mobileInput.value;
        if (val) {
          for (let char of val) {
            this.processInputKey(char, char === ' ' ? 'Space' : ('Key' + char.toUpperCase()));
          }
          this.mobileInput.value = '';
        }
      });
    }

    this.restartBtn.addEventListener('click', () => this.resetTest());
    if (this.modalCloseBtn) this.modalCloseBtn.addEventListener('click', () => this.hideResultsModal());
    if (this.modalRestartBtn) this.modalRestartBtn.addEventListener('click', () => {
      this.hideResultsModal();
      this.resetTest();
    });

    // Custom Text form
    const startCustomBtn = document.getElementById('start-custom-btn');
    if (startCustomBtn) {
      startCustomBtn.addEventListener('click', () => {
        const text = document.getElementById('custom-input-text').value.trim();
        if (text) {
          this.mode = 'custom';
          this.customText = text;
          this.switchTab('test');
          this.resetTest();
        }
      });
    }

    // Settings Dropdowns
    if (this.themeSelect) {
      this.themeSelect.value = this.theme;
      this.themeSelect.addEventListener('change', (e) => this.setTheme(e.target.value));
    }
    if (this.soundSelect) {
      this.soundSelect.value = this.soundProfile;
      this.soundSelect.addEventListener('change', (e) => {
        this.soundProfile = e.target.value;
        localStorage.setItem('typing_sound', this.soundProfile);
        audioSynthesizer.setSoundProfile(this.soundProfile);
      });
    }
  }

  switchTab(tabName) {
    this.navTabs.forEach(t => t.classList.toggle('active', t.getAttribute('data-tab') === tabName));
    this.tabPanes.forEach(p => p.classList.toggle('active', p.id === `${tabName}-pane`));

    if (tabName === 'test') {
      if (this.mobileInput) this.mobileInput.focus();
      this.typingBox.focus();
    }
  }

  setTheme(themeName) {
    this.theme = themeName;
    document.documentElement.setAttribute('data-theme', themeName);
    localStorage.setItem('typing_theme', themeName);
  }

  generateText() {
    if (this.mode === 'custom' && this.customText) {
      return this.customText.split(/\s+/);
    }

    let sourcePool = TextBank.words;
    if (this.subCategory === 'punctuation') {
      sourcePool = TextBank.words.concat(TextBank.punctuationWords);
    } else if (this.subCategory === 'numbers') {
      sourcePool = TextBank.words.concat(TextBank.numberWords);
    } else if (this.subCategory === 'quote') {
      const q = TextBank.quotes[Math.floor(Math.random() * TextBank.quotes.length)];
      return q.split(' ');
    } else if (this.subCategory === 'code') {
      const c = TextBank.codeSnippets[Math.floor(Math.random() * TextBank.codeSnippets.length)];
      return c.split(/\s+/);
    }

    const count = (this.mode === 'words') ? this.wordLimit : 70;
    const result = [];
    for (let i = 0; i < count; i++) {
      const word = sourcePool[Math.floor(Math.random() * sourcePool.length)];
      result.push(word);
    }
    return result;
  }

  resetTest() {
    clearInterval(this.timer);
    this.testActive = false;
    this.testFinished = false;
    this.currentWordIdx = 0;
    this.currentCharIdx = 0;
    this.typedHistory = [];
    this.totalKeystrokes = 0;
    this.correctKeystrokes = 0;
    this.errorKeystrokes = 0;
    this.wpmHistory = [];
    this.mistakeKeyMap = {};
    this.wordsList = this.generateText();
    this.timeLeft = (this.mode === 'time') ? this.timeLimit : 0;

    // Reset Live Stats Display
    this.liveWpm.textContent = '0';
    this.liveAccuracy.textContent = '100%';
    this.liveTimer.textContent = (this.mode === 'time') ? `${this.timeLeft}s` : (this.mode === 'words' ? `${this.wordsList.length} words` : 'Zen');

    // Render HTML words
    this.wordsContainer.innerHTML = '';
    if (this.caret) {
      this.wordsContainer.appendChild(this.caret);
    }
    this.wordsContainer.style.transform = 'translateY(0px)';
    this.wordElements = [];

    this.wordsList.forEach((wStr, wIdx) => {
      const wordSpan = document.createElement('span');
      wordSpan.className = 'word';
      wordSpan.setAttribute('data-word-idx', wIdx);

      for (let i = 0; i < wStr.length; i++) {
        const charSpan = document.createElement('span');
        charSpan.className = 'char';
        charSpan.textContent = wStr[i];
        wordSpan.appendChild(charSpan);
      }

      this.wordsContainer.appendChild(wordSpan);
      this.wordElements.push(wordSpan);
    });

    this.updateCaretPosition();
    this.highlightNextKey();
  }

  startTest() {
    this.testActive = true;
    this.startTime = Date.now();
    this.wpmHistory = [];

    if (this.mode === 'time') {
      this.timer = setInterval(() => {
        this.timeLeft--;
        this.liveTimer.textContent = `${this.timeLeft}s`;

        // Calculate snapshot WPM for graph
        const currentWpm = this.calculateWPM();
        this.wpmHistory.push(currentWpm);
        this.liveWpm.textContent = currentWpm;

        if (this.timeLeft <= 0) {
          this.finishTest();
        }
      }, 1000);
    }
  }

  finishTest() {
    clearInterval(this.timer);
    this.testActive = false;
    this.testFinished = true;

    audioSynthesizer.playCompletionChime();

    const finalWpm = this.calculateWPM();
    const rawWpm = this.calculateRawWPM();
    const accuracy = this.calculateAccuracy();

    // Save to LocalStorage History
    this.saveTestResult({
      date: new Date().toLocaleDateString(),
      wpm: finalWpm,
      accuracy: accuracy,
      mode: `${this.mode} (${this.mode === 'time' ? this.timeLimit + 's' : this.wordLimit + 'w'})`
    });

    // Show Modal
    this.showResultsModal(finalWpm, rawWpm, accuracy);
  }

  handleKeyDown(e) {
    // Avoid handling inputs if modal active or typing in custom textarea
    if (this.resultsModal && this.resultsModal.classList.contains('active')) return;
    if (document.activeElement.tagName === 'TEXTAREA' || (document.activeElement.tagName === 'INPUT' && document.activeElement.id !== 'mobile-input')) return;

    const key = e.key;
    const code = e.code;

    // Prevent default scrolling for Space/Tab
    if (key === ' ' || key === 'Tab') {
      e.preventDefault();
    }

    this.processInputKey(key, code);
  }

  processInputKey(key, code) {
    if (this.resultsModal && this.resultsModal.classList.contains('active')) return;

    const activeTab = document.querySelector('.tab-pane.active');
    if (!activeTab || activeTab.id !== 'test-pane') return;

    // Ignore modifier keys
    if (['Shift', 'Control', 'Alt', 'Meta', 'CapsLock'].includes(key)) {
      keyboardManager.handleKeyDown(code, key);
      return;
    }

    if (this.testFinished) return;

    if (!this.testActive && key.length === 1) {
      this.startTest();
    }

    keyboardManager.handleKeyDown(code, key);
    setTimeout(() => keyboardManager.handleKeyUp(code, key), 150);

    const currentWordStr = this.wordsList[this.currentWordIdx] || '';
    const currentWordEl = this.wordElements[this.currentWordIdx];
    if (!currentWordEl) return;

    let typedCurrentWord = this.typedHistory[this.currentWordIdx] || '';

    // Handle Backspace
    if (key === 'Backspace') {
      if (typedCurrentWord.length > 0) {
        typedCurrentWord = typedCurrentWord.slice(0, -1);
        this.typedHistory[this.currentWordIdx] = typedCurrentWord;
        this.renderWordState(this.currentWordIdx);
        audioSynthesizer.playKeySound(false, false);
      } else if (this.currentWordIdx > 0) {
        // Go back to previous word if incomplete
        this.currentWordIdx--;
        this.renderWordState(this.currentWordIdx);
      }
      this.updateCaretPosition();
      this.highlightNextKey();
      return;
    }

    // Handle Spacebar (Submit Word)
    if (key === ' ') {
      if (typedCurrentWord.length > 0) {
        audioSynthesizer.playKeySound(true, false);
        this.totalKeystrokes++;

        // Mark missing characters as unentered
        this.currentWordIdx++;
        if (this.currentWordIdx >= this.wordsList.length) {
          if (this.mode === 'words' || this.mode === 'custom') {
            this.finishTest();
            return;
          }
        }
        this.updateCaretPosition();
        this.highlightNextKey();
        this.updateLiveStats();
      }
      return;
    }

    // Standard Character Input
    if (key.length === 1) {
      this.totalKeystrokes++;
      const expectedChar = currentWordStr[typedCurrentWord.length];

      if (key === expectedChar) {
        this.correctKeystrokes++;
        audioSynthesizer.playKeySound(false, false);
      } else {
        this.errorKeystrokes++;
        audioSynthesizer.playKeySound(false, true);
        if (expectedChar) {
          this.mistakeKeyMap[expectedChar] = (this.mistakeKeyMap[expectedChar] || 0) + 1;
        }
      }

      typedCurrentWord += key;
      this.typedHistory[this.currentWordIdx] = typedCurrentWord;

      this.renderWordState(this.currentWordIdx);
      this.updateCaretPosition();
      this.highlightNextKey();
      this.updateLiveStats();
    }
  }

  renderWordState(wordIdx) {
    const wordStr = this.wordsList[wordIdx];
    const typedStr = this.typedHistory[wordIdx] || '';
    const wordEl = this.wordElements[wordIdx];
    if (!wordEl) return;

    wordEl.innerHTML = '';

    // Render typed characters
    for (let i = 0; i < Math.max(wordStr.length, typedStr.length); i++) {
      const charSpan = document.createElement('span');
      charSpan.className = 'char';

      if (i < typedStr.length) {
        if (i < wordStr.length) {
          if (typedStr[i] === wordStr[i]) {
            charSpan.classList.add('correct');
          } else {
            charSpan.classList.add('incorrect');
          }
          charSpan.textContent = wordStr[i];
        } else {
          // Extra character typed
          charSpan.classList.add('extra');
          charSpan.textContent = typedStr[i];
        }
      } else {
        // Untyped remaining character
        charSpan.textContent = wordStr[i];
      }
      wordEl.appendChild(charSpan);
    }
  }

  updateCaretPosition() {
    const wordEl = this.wordElements[this.currentWordIdx];
    if (!wordEl || !this.caret || !this.wordsContainer) return;

    const typedStr = this.typedHistory[this.currentWordIdx] || '';
    const charSpans = wordEl.querySelectorAll('.char');
    const containerRect = this.wordsContainer.getBoundingClientRect();

    let left = 0;
    let top = 0;

    if (typedStr.length < charSpans.length) {
      const targetEl = charSpans[typedStr.length];
      if (targetEl) {
        const charRect = targetEl.getBoundingClientRect();
        left = charRect.left - containerRect.left;
        top = charRect.top - containerRect.top;
      }
    } else if (charSpans.length > 0) {
      const lastChar = charSpans[charSpans.length - 1];
      const charRect = lastChar.getBoundingClientRect();
      left = charRect.right - containerRect.left;
      top = charRect.top - containerRect.top;
    }

    this.caret.style.left = `${left}px`;
    this.caret.style.top = `${top}px`;

    // Smooth Line Scrolling
    if (wordEl.offsetTop > 45) {
      this.wordsContainer.style.transform = `translateY(-${wordEl.offsetTop - 10}px)`;
    }
  }

  highlightNextKey() {
    const wordStr = this.wordsList[this.currentWordIdx] || '';
    const typedStr = this.typedHistory[this.currentWordIdx] || '';

    if (typedStr.length < wordStr.length) {
      keyboardManager.highlightTargetKey(wordStr[typedStr.length]);
    } else {
      keyboardManager.highlightTargetKey(' ');
    }
  }

  calculateWPM() {
    if (!this.startTime) return 0;
    const elapsedMinutes = (Date.now() - this.startTime) / 60000;
    if (elapsedMinutes <= 0) return 0;
    // Standard: 5 characters per word
    const netWords = this.correctKeystrokes / 5;
    return Math.max(0, Math.round(netWords / elapsedMinutes));
  }

  calculateRawWPM() {
    if (!this.startTime) return 0;
    const elapsedMinutes = (Date.now() - this.startTime) / 60000;
    if (elapsedMinutes <= 0) return 0;
    return Math.round((this.totalKeystrokes / 5) / elapsedMinutes);
  }

  calculateAccuracy() {
    if (this.totalKeystrokes === 0) return 100;
    return Math.round((this.correctKeystrokes / this.totalKeystrokes) * 100);
  }

  updateLiveStats() {
    this.liveWpm.textContent = this.calculateWPM();
    this.liveAccuracy.textContent = `${this.calculateAccuracy()}%`;
  }

  showResultsModal(wpm, rawWpm, accuracy) {
    document.getElementById('modal-wpm').textContent = wpm;
    document.getElementById('modal-raw').textContent = rawWpm;
    document.getElementById('modal-acc').textContent = `${accuracy}%`;

    // Render timeline graph
    this.renderChart();

    if (this.resultsModal) {
      this.resultsModal.classList.add('active');
    }
  }

  hideResultsModal() {
    if (this.resultsModal) {
      this.resultsModal.classList.remove('active');
    }
  }

  renderChart() {
    const chartContainer = document.getElementById('chart-bars');
    if (!chartContainer) return;
    chartContainer.innerHTML = '';

    if (this.wpmHistory.length === 0) {
      this.wpmHistory.push(this.calculateWPM());
    }

    const maxWpm = Math.max(...this.wpmHistory, 10);

    this.wpmHistory.forEach((val, i) => {
      const bar = document.createElement('div');
      bar.className = 'chart-bar';
      const heightPct = (val / maxWpm) * 100;
      bar.style.height = `${Math.max(8, heightPct)}%`;
      bar.setAttribute('data-tooltip', `${i + 1}s: ${val} WPM`);
      chartContainer.appendChild(bar);
    });
  }

  renderLessonsGrid() {
    const grid = document.getElementById('lessons-grid');
    if (!grid) return;
    grid.innerHTML = '';

    TextBank.lessons.forEach(lesson => {
      const card = document.createElement('div');
      card.className = 'lesson-card';
      card.innerHTML = `
        <div class="lesson-header">
          <span class="lesson-num">${lesson.number}</span>
          <span class="lesson-keys-badge">${lesson.keys}</span>
        </div>
        <div>
          <div class="lesson-title">${lesson.title}</div>
          <div class="lesson-desc">${lesson.desc}</div>
        </div>
        <button class="lesson-start-btn">Start Practice →</button>
      `;

      card.addEventListener('click', () => {
        this.mode = 'custom';
        this.customText = lesson.text;
        this.switchTab('test');
        this.resetTest();
      });

      grid.appendChild(card);
    });
  }

  saveTestResult(result) {
    const history = JSON.parse(localStorage.getItem('typing_history') || '[]');
    history.unshift(result);
    // Keep last 25 tests
    if (history.length > 25) history.pop();
    localStorage.setItem('typing_history', JSON.stringify(history));
    this.loadHistoryStats();
  }

  loadHistoryStats() {
    const history = JSON.parse(localStorage.getItem('typing_history') || '[]');
    const historyBody = document.getElementById('history-table-body');
    const pbWpmEl = document.getElementById('stat-pb-wpm');
    const avgWpmEl = document.getElementById('stat-avg-wpm');
    const totalTestsEl = document.getElementById('stat-total-tests');

    if (history.length > 0) {
      const maxWpm = Math.max(...history.map(h => h.wpm));
      const avgWpm = Math.round(history.reduce((a, b) => a + b.wpm, 0) / history.length);

      if (pbWpmEl) pbWpmEl.textContent = maxWpm;
      if (avgWpmEl) avgWpmEl.textContent = avgWpm;
      if (totalTestsEl) totalTestsEl.textContent = history.length;
    }

    if (historyBody) {
      historyBody.innerHTML = '';
      history.forEach(h => {
        const row = document.createElement('tr');
        row.innerHTML = `
          <td>${h.date}</td>
          <td><strong>${h.wpm} WPM</strong></td>
          <td>${h.accuracy}%</td>
          <td>${h.mode}</td>
        `;
        historyBody.appendChild(row);
      });
    }
  }
}

// Instantiate App when DOM loaded
document.addEventListener('DOMContentLoaded', () => {
  window.app = new TypingApp();
  window.app.init();
});
