/* ==========================================================================
   Typing Web Application - Comprehensive Text & Lesson Repository
   ========================================================================== */

const TextBank = {
  // Top 200 Common English Words
  words: [
    "the", "be", "of", "and", "a", "to", "in", "he", "have", "it", "that", "for", "they", "i", "with",
    "as", "not", "on", "she", "at", "by", "this", "we", "you", "do", "but", "from", "or", "which", "one",
    "would", "all", "will", "there", "say", "who", "make", "when", "can", "more", "if", "no", "man",
    "out", "other", "so", "what", "time", "up", "go", "about", "than", "into", "could", "state", "only",
    "new", "year", "some", "take", "come", "these", "know", "see", "use", "get", "like", "then", "first",
    "any", "work", "now", "may", "such", "give", "over", "think", "most", "even", "find", "day", "also",
    "after", "way", "many", "must", "look", "before", "great", "back", "through", "long", "where", "much",
    "should", "well", "people", "down", "own", "just", "because", "good", "each", "those", "feel", "seem",
    "how", "high", "too", "place", "little", "world", "very", "still", "nation", "hand", "old", "life",
    "tell", "write", "become", "here", "show", "house", "both", "between", "need", "mean", "call", "develop",
    "under", "last", "right", "move", "thing", "general", "school", "never", "same", "another", "begin", "while",
    "number", "part", "turn", "real", "leave", "might", "want", "point", "form", "off", "child", "few",
    "small", "since", "against", "ask", "late", "home", "interest", "large", "person", "end", "open", "public",
    "follow", "during", "present", "without", "again", "hold", "govern", "around", "possible", "head", "consider",
    "word", "program", "problem", "however", "lead", "system", "set", "order", "eye", "plan", "run", "keep"
  ],

  punctuationWords: [
    "the,", "be.", "of!", "and?", "a;", "to:", "in,", "he.", "have!", "it?", "that,", "for.", "they!", "i,",
    "with?", "as;", "not:", "on,", "she.", "at!", "by?", "this,", "we.", "you!", "do?", "but,", "from.",
    "or!", "which?", "one,", "would.", "all!", "will?", "there,", "say.", "who!", "make?", "when,", "can."
  ],

  numberWords: [
    "123", "456", "789", "10", "2024", "100", "50", "99", "3.14", "42", "7", "365", "1000", "88", "25",
    "500", "12", "24", "77", "33", "1999", "2030", "15", "30", "60", "120", "5", "8", "90", "400"
  ],

  quotes: [
    "The journey of a thousand miles begins with a single step.",
    "To be yourself in a world that is constantly trying to make you something else is the greatest accomplishment.",
    "Do not go where the path may lead, go instead where there is no path and leave a trail.",
    "Success is not final, failure is not fatal: it is the courage to continue that counts.",
    "In the middle of every difficulty lies opportunity.",
    "What you do today can improve all your tomorrows.",
    "Strive not to be a success, but rather to be of value.",
    "It always seems impossible until it is done."
  ],

  codeSnippets: [
    "function calculateSpeed(words, timeInSeconds) {\n  return Math.round((words / timeInSeconds) * 60);\n}",
    "const filterEvenNumbers = (arr) => arr.filter(num => num % 2 === 0);",
    "async function fetchData(url) {\n  const res = await fetch(url);\n  return await res.json();\n}",
    "document.addEventListener('DOMContentLoaded', () => {\n  console.log('App initialized!');\n});",
    "import React, { useState, useEffect } from 'react';",
    "class UserProfile {\n  constructor(name, score) {\n    this.name = name;\n    this.score = score;\n  }\n}"
  ],

  // Interactive Touch Typing Practice Lessons
  lessons: [
    {
      id: "lesson-1",
      number: "Lesson 01",
      title: "Home Row Master",
      desc: "Learn to rest your fingers on a s d f (left) and j k l ; (right). Master the foundation of touch typing.",
      keys: "a s d f j k l ;",
      text: "asdf jkl; a s d f j k l ; asdf jkl; fjdksla; aaaa ssss dddd ffff jjjj kkkk llll ;;;; asdfjkl; fj fjd kls; asdf jkl; fds ajs dkl;"
    },
    {
      id: "lesson-2",
      number: "Lesson 02",
      title: "Top Row Reach",
      desc: "Extend your fingers upward to master q w e r t y u i o p.",
      keys: "q w e r t y u i o p",
      text: "qwer tyui op qwer tyuiop quiet water tree your user item open power type write quiet port wipe requite power trout query"
    },
    {
      id: "lesson-3",
      number: "Lesson 03",
      title: "Bottom Row Precision",
      desc: "Reach downward with confidence to cover z x c v b n m , . /.",
      keys: "z x c v b n m , . /",
      text: "zxcv bnm, ./ zxcv bnm zxc vbn m, ./ zero x-ray cat vine box name moon, move, combine vacuum carbon zebra cave bacon"
    },
    {
      id: "lesson-4",
      number: "Lesson 04",
      title: "Number Row & Symbols",
      desc: "Practice quick number row keystrokes without looking down at the keyboard.",
      keys: "1 2 3 4 5 6 7 8 9 0",
      text: "12345 67890 10 20 30 40 50 100 200 999 123 456 7890 54321 98765 1029384756 12 34 56 78 90"
    },
    {
      id: "lesson-5",
      number: "Lesson 05",
      title: "Capitalization & Shift",
      desc: "Use pinky fingers on Left and Right Shift keys to quickly capitalize proper nouns.",
      keys: "Shift + Keys",
      text: "The Quick Brown Fox Jumps Over The Lazy Dog. JavaScript and Python are Popular Languages. London, Tokyo, New York, Paris."
    },
    {
      id: "lesson-6",
      number: "Lesson 06",
      title: "Developer Code Typing",
      desc: "Practice brackets, symbols, curly braces, and code syntax used by software developers.",
      keys: "{ } ( ) [ ] ; => < >",
      text: "const sum = (a, b) => a + b; if (x > 10) { return true; } const items = [1, 2, 3]; console.log('Hello World');"
    }
  ]
};
